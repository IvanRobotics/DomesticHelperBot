from pycreate2 import Create2
import time
import serial
import subprocess
import os
# initialize variables and ports
port = "/dev/ttyUSB0"
bot = Create2(port)
ser = serial.Serial(port, baudrate = 115200)
sensors = bot.get_sensors()
time = 20

def bumperSensor(time):
   
    for i in range(time):
        sensors = bot.get_sensors()
        leftBump = sensors.bumps_wheeldrops[0]
        rightBump = sensors.bumps_wheeldrops[1]
        print('left:',leftBump, 'right: ',rightBump)
        if leftBump == True and rightBump == True:
            os.system('echo "1" > ~/Desktop/roombaBOT/bot_fifo')
        if leftBump == True and rightBump == False:
            os.system('echo "2" > ~/Desktop/roombaBOT/bot_fifo')
        if leftBump == False and rightBump == True:
            os.system('echo "3" > ~/Desktop/roombaBOT/bot_fifo')
 
        else:
            os.system('echo "4" > ~/Desktop/roombaBOT/bot_fifo')