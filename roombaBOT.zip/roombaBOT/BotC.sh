python BotBump.py&
python BotMove.py
