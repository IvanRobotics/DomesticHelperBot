import subprocess
import os

print('hello')
a = os.system('cat ~/Desktop/roombaBOT/bot_fifo')

    
flag = a
print(flag)