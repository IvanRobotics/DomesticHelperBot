python readTest.py
